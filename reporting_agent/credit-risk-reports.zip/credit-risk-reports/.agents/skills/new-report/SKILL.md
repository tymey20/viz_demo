---
name: new-report
description: Create a new recurring report folder from an existing rpt_* mart. Use when asked to add, create, or convert a report, replace a Tableau view, or rebuild a screenshot-based pack.
---
# New report

1. Get from the requester: title, owner, cadence, the marts involved, the predefined filters
   (and which should be parameters), columns to show, thresholds with their policy source, and
   the sort order. Do not invent thresholds; leave `thresholds:` empty and note it if unknown.
2. Confirm each mart is `rpt_*`. If the data isn't in a governed mart yet, or needs a join/
   pivot/aggregation, stop: the first deliverable is the dbt model, not the report.
3. Copy the closest example (`reports/pd_monitoring_quarterly` for monitoring,
   `reports/raroc_committee` for multi-table committee packs) to `reports/<id>/spec.yaml`.
   Set `formats:` for every numeric column using names from `reportkit/formats.py`.
4. Add `fixtures/<mart>.csv` with synthetic rows matching the mart's columns (if not present).
5. Add `("<id>", {params})` to `REPORTS` in `tests/test_reports.py`.
6. Run `pytest` and `reportkit build`. Render to images (validate-report skill) and check layout.
7. Report: output paths, validation result, and any thresholds/sources still to be confirmed.
