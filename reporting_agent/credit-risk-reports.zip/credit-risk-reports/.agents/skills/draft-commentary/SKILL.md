---
name: draft-commentary
description: Draft or revise report commentary from system-generated facts. Use when asked to write, draft, improve, or update the narrative for a report run.
---
# Draft commentary

1. `reportkit facts reports/<id> -p as_of=<date>` and read the JSON. The default build already
   generates rule-based commentary; only write a draft if the requester wants narrative beyond it.
2. Write `reports/<id>/commentary/<as_of>.md`:
   ```
   ---
   drafted_by: agent
   facts_file: out/<id>_<as_of>_facts.json
   signed_off_by:
   ---
   <one observation per line, following STYLE.md commentary rules>
   ```
3. Every number must appear verbatim (as formatted) in the facts file. `reportkit check`
   fails on any other number. Years, quarters, and dates are exempt.
4. Red before Amber. State breaches plainly. No causes unless a driver is in the facts;
   write "Question for review: ..." instead.
5. Leave `signed_off_by` empty.
6. `reportkit check reports/<id> -p as_of=<date>` then rebuild; confirm the slide shows DRAFT.
