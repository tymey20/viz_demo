---
name: validate-report
description: Validate a rendered report for reconciliation errors, ungrounded commentary, missing provenance, and visual defects. Use before any report is distributed or when a build fails.
---
# Validate report

1. `reportkit build reports/<id> -p as_of=<date>` reconciles every table cell and chart point to
   source and checks commentary grounding. Read every `VALIDATION:` line.
2. Render for visual review:
   `soffice --headless --convert-to pdf out/<file>.pptx && pdftoppm -jpeg -r 110 out/<file>.pdf out/slide`
3. Inspect each image: text overflow or truncation, overlapping shapes, unreadable axis labels,
   empty exhibits, footer collisions, RAG colors used for anything other than status.
4. Confirm the Commentary slide shows the correct sign-off status.
5. Report findings by slide number. Fix bugs in `reportkit/` or the spec, never in the output.
