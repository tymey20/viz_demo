---
name: add-exhibit
description: Add a new exhibit type to reportkit so every report can use it. Use when a spec needs a chart or table variant the registry doesn't have.
---
# Add exhibit

1. Create `reportkit/exhibits/<name>.py` with a pydantic class extending `Exhibit`:
   `type: Literal["<name>"]`, its fields, and `render_pptx`, `render_html`, `reconcile`.
   Model on `bar.py` (category charts) or `line.py` (time series).
2. Register it in the `AnyExhibit` union in `reportkit/exhibits/__init__.py`.
3. Native PowerPoint objects only. Use `_chart.add_chart` and `_chart.reconcile_chart`.
   Colors and fonts from `reportkit/style.py`; number formats via `ctx.spec.fmt(col)`.
4. `reconcile` must compare every number the exhibit displays to source, or the exhibit is
   not done.
5. Add a test in `tests/`, use the type in one example spec, run `pytest` and build, and
   view the rendered slide.
